const login = {
    paperStyle: { padding: 20, height: '70vh', width: 280, margin: "20px auto" },
    avatarStyle: { backgroundColor: '#1bbd7e' },
    btnstyle: { margin: '8px 0' }
}